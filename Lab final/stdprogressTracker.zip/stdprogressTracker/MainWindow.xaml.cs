﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;

namespace StudentProgressTracker
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Student> Students { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Students = new ObservableCollection<Student>();
            StudentsDataGrid.ItemsSource = Students;

            LoadSampleData();
        }

        private void LoadSampleData()
        {
            // Sample data (replace with database fetching logic)
            Students.Add(new Student { Name = "maryum", Grade = "9", Subject = "Math", Marks = 85, AttendancePercentage = 90 });
            Students.Add(new Student { Name = "fatima", Grade = "10", Subject = "Science", Marks = 92, AttendancePercentage = 95 });
            Students.Add(new Student { Name = " kinza", Grade = "10", Subject = "computer Science ", Marks = 100, AttendancePercentage = 100 });
            Students.Add(new Student { Name = " maham", Grade = "10", Subject = "computer Science ", Marks = 100, AttendancePercentage = 100 });
            Students.Add(new Student { Name = " mahneen", Grade = "10", Subject = "computer Science ", Marks = 100, AttendancePercentage = 100 });
            Students.Add(new Student { Name = " javeria", Grade = "10", Subject = "computer Science ", Marks = 100, AttendancePercentage = 100 });
        }

        // Event: ComboBox Selection Changed
        private void GradeComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            FilterData();
        }

        private void SubjectComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            FilterData();
        }

        // Event: Filter Button Click
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            FilterData();
        }

        // Filter data based on ComboBox selections
        private void FilterData()
        {
            string selectedGrade = GradeComboBox.SelectedItem as string;
            string selectedSubject = SubjectComboBox.SelectedItem as string;

            // Filter logic (apply filter to Students collection)
            // Implement database query here if needed
        }

        // Event: Add Student Button Click
        private void AddStudentButton_Click(object sender, RoutedEventArgs e)
        {
            // Add a new student
            Student newStudent = new Student { Name = "New Student", Grade = "10", Subject = "English", Marks = 0, AttendancePercentage = 0 };
            Students.Add(newStudent);
        }

        // Event: Edit Student Button Click
        private void EditStudentButton_Click(object sender, RoutedEventArgs e)
        {
            if (StudentsDataGrid.SelectedItem is Student selectedStudent)
            {
                // Edit the selected student
                selectedStudent.Marks += 5; // Example logic
            }
        }

        // Event: Delete Student Button Click
        private void DeleteStudentButton_Click(object sender, RoutedEventArgs e)
        {
            if (StudentsDataGrid.SelectedItem is Student selectedStudent)
            {
                Students.Remove(selectedStudent);
            }
        }

        // Asynchronous Save Data method
        private async void SaveDataAsync()
        {
            ProgressBar.Visibility = Visibility.Visible;
            await Task.Run(() =>
            {
                // Simulate time-consuming save operation
                Task.Delay(3000).Wait();
            });
            ProgressBar.Visibility = Visibility.Collapsed;
        }
    }

    // Student class with INotifyPropertyChanged
    public class Student : INotifyPropertyChanged
    {
        private string name;
        public string Name
        {
            get => name;
            set { name = value; OnPropertyChanged(); }
        }

        private string grade;
        public string Grade
        {
            get => grade;
            set { grade = value; OnPropertyChanged(); }
        }

        private string subject;
        public string Subject
        {
            get => subject;
            set { subject = value; OnPropertyChanged(); }
        }

        private int marks;
        public int Marks
        {
            get => marks;
            set { marks = value; OnPropertyChanged(); }
        }

        private double attendancePercentage;
        public double AttendancePercentage
        {
            get => attendancePercentage;
            set { attendancePercentage = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
